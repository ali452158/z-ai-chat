# Add project specific ProGuard rules here.
-keepclassmembers class * {
    public <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-dontwarn android.webkit.**